//--------------------------SumZero--------------------------------------------------------------------------

function sumZero(A) //A is an array of numbers passed as a parameter
{
    let indicator = 0 //as soon as the function finds a pair of numbers the sum of which equals zero, the indicator will increase by 1
    for (i=0;i<A.length;i++) //Here we iterate through the array to check if the sum of each element with each of the rest of elemenst equals 0
    {
        for (j=0; j<A.length;j++)
        {
            if(A[i] + A[j] == 0)
            {
indicator++
            }
        }
        
        
        
    }
    if (indicator > 0) //if the indicator remains 0, then there is at leats one pair of numbers whose sum is 0, so the function will return true
        {
            return true
        }

        else
        {
            return false
        }
}


//-----------------------Unique Characters-------------------------------------------------------------------
function uniqueChar(Str)// The function takes in a string
{

    let indicator =0 //the indicator will increase by 1 if there is at least one pair of identical characters

let Ar = Str.split('') //here we convert teh string into an array of characters




for (let i=0; i< Ar.length; i++)
{
    for (let j=(i+1); j<Ar.length; j++)
    
if(Ar[i]==Ar[j])
{
    indicator +=1
}
    }
    if(indicator>0)
{
    return (false)
}
else
{
    return (true)
}
}


//-----------------------Pangram Sentence--------------------------------------------------------------------
let EnglishAlphabet = 'abcdefghijklmnopqrstuvwxyz'
function pangram(str) //the function takes in a string
{
    let LCstring = str.toLowerCase() //all characters in the string are converted into lower-case-characters
let accumulator =[] //the accumulator will store all unique characters included in the string that is passed as a parameter
let Ar  = LCstring.split('') //LCstring is the lower-cased parameter-string converted into an array of characters
let l = EnglishAlphabet.length

for (let i=0; i< l; i++) //Heer we loop through the English alphabet. If the parameter-string includes the current character, and if the current character is not  in teh accumulator array, we add this character into teh accumulator 
{
    for (let j = 0; j<Ar.length; j++)
    {
        if((accumulator.includes(EnglishAlphabet[i])==false)&&(Ar[j]==EnglishAlphabet[i]))
        {
            accumulator.push(Ar[j])
        }
    }
}
if (accumulator.length == 26) //if accumulator contains 26 chatracters, which is teh length if teh English alphabet, the sentence is a pangram
{
    return('The sentence is a pangram')
}
else
{
    return('The sentence is not a pangram')
}
}

//-----------------------Longest Word------------------------------------------------------------------------

function longestWord(words) //words is an array of strings
{
let maxlength = 0 //maxlength stores teh length of the longest word
let longestWords = [] //the function will add the logest words to this array, and it will return this array as a result
    let l = words.length //we need the length of the array of words in order to loop through it
    let lengthAccumulator = [] //this array will store the length of every word in teh array of strings passed as a parameter
let keyValAccumulator = [] //this array will store objects, each of which has two properties--the word and its length
    for(i=0;i<l;i++)
    {
lengthAccumulator.push(words[i].length) //this is where we push the length of each word into an array called lengthAccumulator

let wordObj = {word:words[i], wordLength:words[i].length} //this is where we create a word object with two properties --the word itself and its length
keyValAccumulator.push(wordObj) //this is where we push the words and their lengths into an array of objects called wordObj
    }
maxlength = Math.max(...lengthAccumulator) //this is where we find the max length in teh array of lengths

for (let k=0;k<keyValAccumulator.length;k++) //this is where we iterate through the array of word-objects. Those word objects whose length matches the length of maxlength get added to the array called longestWords
{
    if (keyValAccumulator[k].wordLength==maxlength)
    {
        longestWords.push(keyValAccumulator[k])
    }
}

return(longestWords)
}
//-------------------------------testing uniqueChar-function with dummy data -------------------------------
console.log('------------------------------------------------------------------------------------------')
console.log('------------------------------------------------------------------------------------------')
console.log(`TESTING uniqueChar-function with dummy data`)
let testString = 'abcdefa'
console.log(`passing ${testString} as an argument`)
if (uniqueChar(testString)==true)
{
    console.log(`${testString} is a string of unique characters`)
}

else if (uniqueChar(testString)==false)
{
console.log(`${testString} is not a string of unique characters`)
}
console.log('------------------------------------------------------------------------------------------')
console.log('------------------------------------------------------------------------------------------')



//------------testing the function sumZero with dummy data---------------------------------------------------
let testArray = [10,9,8,7,-8]
console.log(`TESTING the function sumZero with dummy data`)
console.log(`Passing the following array as an argument: ${testArray}`)
console.log(`For ${testArray}, the value of sumZero is ${sumZero(testArray)}`)
console.log('------------------------------------------------------------------------------------------')
console.log('------------------------------------------------------------------------------------------')

//-----------------------------------TESTING pangram-function with dummy data--------------------------

console.log(`TESTING pangram-function with dummy data`)
let testSentence ='The quick brown fox jumps over the lazy dog'
console.log(`Passing the following senetence as an argument: ${testSentence}. ${pangram(testSentence)}`)
//--------------------------TESTING the function longestWord with dummy data---------------------------------
console.log(`TESTING the function longestWord with dummy data`)
console.log('------------------------------------------------------------------------------------------')
console.log('------------------------------------------------------------------------------------------')
let testData = ["Hello", "Hi", "Greetings", "Morning"]
console.log(`Passing the following array as a parameter: ${testData}`)
let LWs = longestWord(testData)
console.log('See the longest words below:')
for (let i=0; i<LWs.length; i++)
{
console.log(`Word: ${LWs[i].word} with the Length of ${LWs[i].wordLength}`)
}

console.log('------------------------------------------------------------------------------------------')
console.log('------------------------------------------------------------------------------------------')

