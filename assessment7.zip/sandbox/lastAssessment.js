const perf = require('execution-time')()

//function getSizedArray returns an array of integers from 0 to (size-1)

function getSizedArray(size)
{
    let result = []
for (let i=0; i<size; i++)
{
    result.push(i)
}
return (result)
}


//creation of test arrays
let tinyArray = getSizedArray(10)
let smallArray = getSizedArray(100)
let mediumArray = getSizedArray(1000)
let largeArray = getSizedArray(10000)
let extraLargeArray = getSizedArray(100000)

//function doublerAppend loops through an array, doubles the value of each element, and pushes the result into a blank array. At the end, the function returns the array with the doubled values. The function is built around the .push-method, which adds a new element to the END of an array


function doublerAppend(nums)
{
    let new_nums = []
    for (let i = 0; i<nums.length; i++)
    {
        let num = nums[i]*2
        new_nums.push(num)
        
    }
}

//function doublerAppend loops through an array, doubles the value of each element and adds the result to the beginning of a blank array. The function is built around the .unsift() method, which adds a new element to teh beginning to an array


function doublerInsert(nums)
{
    let new_nums = []
for (let i=0;i<nums.length;i++)
{
    let num = nums[i]*2
    new_nums.unshift(num)
}

}


//MEASURING EXECUTION TIMES


//---------------TINY ARRAY--------------------------------------------------------------------------------//
console.log('----------------------TINY ARRAY--------------------------------')
perf.start()
doublerAppend(tinyArray)
let resultAppendTiny = perf.stop()
console.log(`For a tiny array, the doublerAppend function took ${resultAppendTiny.preciseWords} milliseconds to run`)

perf.start()
doublerInsert(tinyArray)
let resultInsertTiny = perf.stop()
console.log(`For a tiny array, the doublerInsert function took ${resultInsertTiny.preciseWords} milliseconds to run`)

//---------------SMALL ARRAY-------------------------------------------------------------------------------//
console.log('----------------------SMALL ARRAY--------------------------------')
perf.start()
doublerAppend(smallArray)
let resultAppendSmall = perf.stop()
console.log(`For a small array, the doublerAppend function took ${resultAppendSmall.preciseWords} milliseconds to run`)

perf.start()
doublerInsert(smallArray)
let resultInsertSmall = perf.stop()
console.log(`For a small array, the doublerInsert function took ${resultInsertSmall.preciseWords} milliseconds to run`)

//---------------MEDIUM RRAY------------------------------------------------------------\------------------//
console.log('----------------------MEDIUM ARRAY--------------------------------')
perf.start()
doublerAppend(mediumArray)
let resultAppendMedium = perf.stop()
console.log(`For a medium array, the doublerAppend function took ${resultAppendMedium.preciseWords} milliseconds to run`)

perf.start()
doublerInsert(mediumArray)
let resultInsertMedium = perf.stop()
console.log(`For a medium array, the doublerInsert function took ${resultInsertMedium.preciseWords}`)
//---------------LARGE ARRAY-------------------------------------------------------------------------------//
console.log('----------------------LARGE ARRAY--------------------------------')
perf.start()
doublerAppend(largeArray)
let resultAppendLarge = perf.stop()
console.log(`For a large array, the doublerAppend function took ${resultAppendMedium.preciseWords} milliseconds to run`)

perf.start()
doublerInsert(largeArray)
let resultInsertLarge = perf.stop()
console.log(`For a large array, the doublerInsert function took ${resultInsertMedium.preciseWords}`)
//---------------EXTRA LARGE ARRAY-------------------------------------------------------------------------//
console.log('----------------------EXTRA LARGE ARRAY--------------------------------')
perf.start()
doublerAppend(extraLargeArray)
let resultAppendExtraLarge = perf.stop()
console.log(`For an extra large array, doublerAppend function took ${resultAppendExtraLarge.preciseWords} miliseconds to run`)

perf.start()
doublerInsert(extraLargeArray)
let resultInsertExtraLarge = perf.stop()
console.log(`For an extra large array, the doublerInsert function took ${resultInsertExtraLarge.preciseWords} milliseconds to run`)
